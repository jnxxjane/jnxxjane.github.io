<!DOCTYPE html>
	<html>

		<head>

			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-case=1">
			<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
			<link rel="stylesheet" type="text/css" href="css/css.css" type="text/css"/>
			<style type="text/css">
				body
					{
						background-image: url("asset/edrein/background.jpg");
						background-position: center;
						background-attachment: fixed;
						background-size: 100%; 
						color: black;
						text-shadow: 1px 1px 1px white;
					}

				img
					{height: 500px!important;}

				a
					{color: black; font-size: 30px}

				p
					{
						color: black;
						text-shadow: 1px 0 1px #20b2aa;
						font-size: 16px;
						margin-left: 5px;
					}

			</style>

			<title>Gallery</title>


		</head>

		<body>

		<header>
			<div class="container">
				<nav class="navbar" role="navigation"> 
				   <div class="navbar-header"> 
				      <button type="button" class="navbar-toggle" data-toggle="collapse"  
				         data-target="#example-navbar-collapse"> 
				         <span class="sr-only">Toggle navigation</span> 
				         <span class="icon-bar"></span> 
				         <span class="icon-bar"></span> 
				         <span class="icon-bar"></span> 
				      </button> 
				   </div> 
				   <div class="collapse navbar-collapse" id="example-navbar-collapse"> 
				      <ul class="nav navbar-nav nav-pills pull-right"> 
				         <li><a href="index.php">Home</a></li> 
				         <li><a href="pic.php">Gallery</a></li> 
				         <li><a href="salon.php">Salon</a></li> 
				         <li><a href="spa.php">Spa</a></li> 
				       	 </ul> 
				      </ul> 
				   </div> 
				</nav>
			</div>
		</header>	

		<div class="container">
			<br>
			<h1 style="color: black;text-shadow: 1px 1px 1px white"><span class="glyphicon glyphicon-camera"></span> Photo Gallery</h1>
			<hr>
				<div id="myCarousel" class="carousel slide"> 
				   <!-- Carousel indicators --> 
				   <ol class="carousel-indicators"> 
				      <li data-target="#myCarousel" data-slide-to="0" class="active"></li> 
				      <li data-target="#myCarousel" data-slide-to="1"></li> 
				      <li data-target="#myCarousel" data-slide-to="2"></li> 
				      <li data-target="#myCarousel" data-slide-to="3"></li> 
				      <li data-target="#myCarousel" data-slide-to="4"></li> 
				      <li data-target="#myCarousel" data-slide-to="5"></li> 
				      <li data-target="#myCarousel" data-slide-to="6"></li> 
				      <li data-target="#myCarousel" data-slide-to="7"></li> 
				      <li data-target="#myCarousel" data-slide-to="8"></li> 
				      <li data-target="#myCarousel" data-slide-to="9"></li> 
				      <li data-target="#myCarousel" data-slide-to="10"></li> 
				      <li data-target="#myCarousel" data-slide-to="11"></li>
				      <li data-target="#myCarousel" data-slide-to="12"></li> 
				      <li data-target="#myCarousel" data-slide-to="13"></li>
				      <li data-target="#myCarousel" data-slide-to="14"></li>
				      <li data-target="#myCarousel" data-slide-to="15"></li>
				      <li data-target="#myCarousel" data-slide-to="16"></li>
				      <li data-target="#myCarousel" data-slide-to="17"></li>
				      <li data-target="#myCarousel" data-slide-to="18"></li>
				      <li data-target="#myCarousel" data-slide-to="19"></li>
				      <li data-target="#myCarousel" data-slide-to="20"></li>
				      <li data-target="#myCarousel" data-slide-to="21"></li>
				      <li data-target="#myCarousel" data-slide-to="22"></li>
				      <li data-target="#myCarousel" data-slide-to="23"></li>
				      <li data-target="#myCarousel" data-slide-to="24"></li>
				   </ol>    
				   <!-- Carousel items --> 
				   <div class="carousel-inner" align="center" style="background-color: rgba(0,0,0,0.8);border: solid thick #222;"> 
				      <div class="item active"> 
				         <a href="asset/edrein/1.jpg" target="_blank"><img src="asset/edrein/A.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/2.jpg" target="_blank"><img src="asset/edrein/B.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/3.jpg" target="_blank"><img src="asset/edrein/C.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/4.jpg" target="_blank"><img src="asset/edrein/D.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/5.jpg" target="_blank"><img src="asset/edrein/E.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/6.jpg" target="_blank"><img src="asset/edrein/F.jpg"></a>
				      </div>  
				      <div class="item"> 
				         <a href="asset/edrein/7.jpg" target="_blank"><img src="asset/edrein/G.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/8.jpg" target="_blank"><img src="asset/edrein/H.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/9.jpg" target="_blank"><img src="asset/edrein/I.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/10.jpg" target="_blank"><img src="asset/edrein/J.jpg"></a>
				      </div>  
				      <div class="item"> 
				         <a href="asset/edrein/11.jpg" target="_blank"><img src="asset/edrein/K.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/12.jpg" target="_blank"><img src="asset/edrein/L.jpg"></a>
				      </div>
				      <div class="item"> 
				         <a href="asset/edrein/13.jpg" target="_blank"><img src="asset/edrein/M.jpg"></a>
				      </div>
 				      <div class="item"> 
				         <a href="asset/edrein/14.jpg" target="_blank"><img src="asset/edrein/N.jpg"></a>
				      </div>
 				      <div class="item"> 
				         <a href="asset/edrein/15.jpg" target="_blank"><img src="asset/edrein/O.jpg"></a>
				      </div>
			 	      <div class="item"> 
				         <a href="asset/edrein/16.jpg" target="_blank"><img src="asset/edrein/P.jpg"></a>
				      </div>
 				      <div class="item"> 
				         <a href="asset/edrein/17.jpg" target="_blank"><img src="asset/edrein/Q.jpg"></a>
				      </div>
				      <div class="item"> 
				         <a href="asset/edrein/18.jpg" target="_blank"><img src="asset/edrein/R.jpg"></a>
				      </div>
 				      <div class="item"> 
				         <a href="asset/edrein/19.jpg" target="_blank"><img src="asset/edrein/S.jpg"></a>
				      </div>
				      <div class="item"> 
				         <a href="asset/edrein/20.jpg" target="_blank"><img src="asset/edrein/T.jpg"></a>
				      </div> 
 				      <div class="item"> 
				         <a href="asset/edrein/21.jpg" target="_blank"><img src="asset/edrein/U.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/22.jpg" target="_blank"><img src="asset/edrein/V.jpg"></a>
				      </div> 
 				      <div class="item"> 
				         <a href="asset/edrein/23.jpg" target="_blank"><img src="asset/edrein/W.jpg"></a>
				      </div> 
 				      <div class="item"> 
				         <a href="asset/edrein/24.jpg" target="_blank"><img src="asset/edrein/X.jpg"></a>
				      </div> 
				       <div class="item"> 
				         <a href="asset/edrein/25.jpg" target="_blank"><img src="asset/edrein/Y.jpg"></a>
				      </div>
				   </div> 
				   <a class="carousel-control left" href="#myCarousel"  
				      data-slide="prev">&lsaquo;</a> 
				   <a class="carousel-control right" href="#myCarousel"  
				      data-slide="next">&rsaquo;</a> 
				</div> 
		</div>


		<div>
			<nav class="navbar-fixed-bottom text-center">
				&copyEdrein Salon and Spa
			</nav>
		</div>

		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script> 
		<script src="jquery/jquery-3.1.1.min.js"></script>
		<script src="jquery/jquery-3.1.1.slim.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>


		</body>

	</html>