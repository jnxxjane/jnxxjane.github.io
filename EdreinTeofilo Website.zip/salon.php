<!DOCTYPE html>
	<html>

		<head>

			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-case=1">
			<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
			<link rel="stylesheet" type="text/css" href="css/css.css" type="text/css"/>
			<style type="text/css">
				body
					{
						background-image: url("asset/edrein/background.jpg");
						background-position: center;
						background-attachment: fixed;
						background-size: 100%; 
						color: black;
						text-shadow: 1px 1px 1px white;
					}

				img
					{height: 500px!important;}

				a
					{color: black; font-size: 30px}

				figcaption
					{
						color: black;
						text-shadow: 1px 0 1px #006600;
						font-size: 16px;
						margin-left: 5px;
					}

				.au
					{margin: 3em auto;}
			</style>

			<title>Salon</title>


		</head>

		<body>

		<header>
			<div class="container">
				<nav class="navbar" role="navigation"> 
				   <div class="navbar-header"> 
				      <button type="button" class="navbar-toggle" data-toggle="collapse"  
				         data-target="#example-navbar-collapse"> 
				         <span class="sr-only">Toggle navigation</span> 
				         <span class="icon-bar"></span> 
				         <span class="icon-bar"></span> 
				         <span class="icon-bar"></span> 
				      </button> 
				   </div> 
				   <div class="collapse navbar-collapse" id="example-navbar-collapse"> 
				      <ul class="nav navbar-nav nav-pills pull-right"> 
				         <li><a href="index.php">Home</a></li> 
				         <li><a href="pic.php">Gallery</a></li> 
				         <li><a href="salon.php">Salon</a></li> 
				         <li><a href="spa.php">Spa</a></li> 
				            </ul> 
				         </li> 
				      </ul> 
				   </div> 
				</nav>
			</div>
		</header>	

		<body>

		<div class="container">

			<div class="col-lg-6"  style="background-color: rgba(0,0,0,0.4); border-radius: 3em; margin-top: 5em;margin-left: 2em">
				<br>
				
				<h1>SALON</h1>
				<div><hr><br>
					<h3>HAIRCUTS</h3>
					<li>women’s haircut/style - P95 &amp; up</li>
					<li>men’s haircut - P85 &amp; up</li>
					<li>child's haircut - P70 &amp; up</li>
					<li>shampoo blow dry - P100 &amp; up</li>
					<li>special occasion - P150 &amp; up</li>
					<li>simple occasion - P100 &amp; up</li>
					
					<h3>COLOR AND FOILING</h3>
					<li>color fusion or gloss - P150 &amp; up</li>
					<li>chromatics - P130 &amp; up</li>
					<li>add color if needed - P90</li>
					<li>double process blonde - P110 &amp; up</li>
					<li>full foils - P120 &amp; up</li>
					<li>partial foils - P110 &amp; up</li>
					<li>ala carte - 75, per foil - P65</li>
					<li>dimensional foil / 2 colors - P170 &amp; up</li>
					<li>ombre color - P120 &amp; up</li>
					<li>mens camo color - P100</li>
					<li>color face frame foil - P130</li>
					<li>brow tint - P95</li>
					<li>Olaplex System - P100</li><br>
					
					<h3>HAIR EXTENSIONS</h3>
					<li>16″ inch - P150/each</li>
					<li>18″ inch - P200/each</li>
					<li>22″ inch - P250/each</li>
					<br><li>P350 - &amp; up for installation</li></br>
					<li>P105 for removal</li>
					<br><hr>
				</div>

		<div>
			<nav class="navbar-fixed-bottom text-center">
				&copyEdrein Salon and Spa
			</nav>
		</div>

		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script> 
		<script src="jquery/jquery-3.1.1.min.js"></script>
		<script src="jquery/jquery-3.1.1.slim.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>


		</body>

	</html>