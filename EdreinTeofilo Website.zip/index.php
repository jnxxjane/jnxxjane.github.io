<!DOCTYPE html>
	<html>

		<head>

			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-case=1">
			<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
			<link rel="stylesheet" type="text/css" href="css/css.css" type="text/css"/>
			<style type="text/css">
				body
					{
						background-image: url("asset/edrein/background.jpg");
						background-position: center;
						background-attachment: fixed;
						background-size: 100%; 
						color: black;
						text-shadow: 1px 1px 1px white;
					}

				p
					{
						color: black;
						text-shadow: 1px 0 1px #006600;
						font-size: 16px;
						margin-left: 5px;
					}

				h3,p
					{display: inline;}

			</style>

			<title>Home</title>


		</head>

		<body>

		<div class="container">
			<br>
			<a href="home.html" target="_self" class="site_logo"><img src="asset/edrein/FINAL.png" border="0" width="1000" height="250"></a>
			<hr>
				<div id="myCarousel" class="carousel slide"> 
				   <!-- Carousel indicators --> 
				   <ol class="carousel-indicators"> 
				      <li data-target="#myCarousel" data-slide-to="0" class="active"></li> 
				      <li data-target="#myCarousel" data-slide-to="1"></li> 
				      <li data-target="#myCarousel" data-slide-to="2"></li> 
				      <li data-target="#myCarousel" data-slide-to="3"></li> 
				      <li data-target="#myCarousel" data-slide-to="4"></li> 
				      <li data-target="#myCarousel" data-slide-to="5"></li> 
				      <li data-target="#myCarousel" data-slide-to="6"></li> 
				      <li data-target="#myCarousel" data-slide-to="7"></li> 
				      <li data-target="#myCarousel" data-slide-to="8"></li> 
				      <li data-target="#myCarousel" data-slide-to="9"></li> 
				      <li data-target="#myCarousel" data-slide-to="10"></li> 

				   </ol>    
				   <!-- Carousel items --> 
				   <div class="carousel-inner" align="center" style="background-color: rgba(0,0,0,0.8);border: solid thick #222;"> 
				      <div class="item active"> 
				         <a href="asset/edrein/1.jpg" target="_blank"><img src="asset/edrein/1.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/2.jpg" target="_blank"><img src="asset/edrein/2.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/3.jpg" target="_blank"><img src="asset/edrein/3.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/4.jpg" target="_blank"><img src="asset/edrein/4.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/5.jpg" target="_blank"><img src="asset/edrein/5.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/6.jpg" target="_blank"><img src="asset/edrein/6.jpg"></a>
				      </div>  
				      <div class="item"> 
				         <a href="asset/edrein/7.jpg" target="_blank"><img src="asset/edrein/7.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/8.jpg" target="_blank"><img src="asset/edrein/8.jpg"></a>
				      </div> 
				      <div class="item"> 
				         <a href="asset/edrein/9.jpg" target="_blank"><img src="asset/edrein/9.jpg"></a>
				      </div> 
				      
				   </div> 
				   <a class="carousel-control left" href="#myCarousel"  
				      data-slide="prev">&lsaquo;</a> 
				   <a class="carousel-control right" href="#myCarousel"  
				      data-slide="next">&rsaquo;</a> 
				</div> 
		</div>

				<div class="text-center">
					<a href="pic.php"><input type="button" value="Gallery" class="btn-success btn-lg"></a>
					<a href="salon.php"><input type="button" value="Salon" class="btn-success btn-lg"></a>
					<a href="spa.php"><input type="button" value="Spa" class="btn-success btn-lg"></a>
					<br><br>
				</div>
			</div>

		</div>


		<div>
			<nav class="navbar-fixed-bottom text-center">
				&copyEdrein Salon and Spa
			</nav>
		</div>

		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script> 
		<script src="jquery/jquery-3.1.1.min.js"></script>
		<script src="jquery/jquery-3.1.1.slim.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>


		</body>

	</html>