<!DOCTYPE html>
	<html>

		<head>

			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-case=1">
			<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
			<link rel="stylesheet" type="text/css" href="css/css.css" type="text/css"/>
			<style type="text/css">
				body
					{
						background-image: url("asset/edrein/background.jpg");
						background-position: center;
						background-attachment: fixed;
						background-size: 100%; 
						color: black;
						text-shadow: 1px 1px 1px white;
					}

				img
					{height: 500px!important;}

				a
					{color: black; font-size: 30px}

				figcaption
					{
						color: black;
						text-shadow: 1px 0 1px #006600;
						font-size: 16px;
						margin-left: 5px;
					}

				.au
					{margin: 3em auto;}
			</style>

			<title>Spa</title>


		</head>

		<body>

		<header>
			<div class="container">
				<nav class="navbar" role="navigation"> 
				   <div class="navbar-header"> 
				      <button type="button" class="navbar-toggle" data-toggle="collapse"  
				         data-target="#example-navbar-collapse"> 
				         <span class="sr-only">Toggle navigation</span> 
				         <span class="icon-bar"></span> 
				         <span class="icon-bar"></span> 
				         <span class="icon-bar"></span> 
				      </button> 
				   </div> 
				   <div class="collapse navbar-collapse" id="example-navbar-collapse"> 
				      <ul class="nav navbar-nav nav-pills pull-right"> 
				         <li><a href="index.php">Home</a></li> 
				         <li><a href="pic.php">Gallery</a></li> 
				         <li><a href="salon.php">Salon</a></li> 
				         <li><a href="spa.php">Spa</a></li> 
				            </ul> 
				         </li> 
				      </ul> 
				   </div> 
				</nav>
			</div>
		</header>	

		<body>

		<div class="container">

			<div class="col-lg-6"  style="background-color: rgba(0,0,0,0.4); border-radius: 3em; margin-top: 5em;margin-left: 3em">
			
			<h1>SPA</h1>
			<div><hr><br>	
			<h3>MASSAGES<h3>
			<li>30 minute massage - P230</li>
			<li>60 minute massage - P260</li>
			<li>90 minute massage - P290</li>
			
			<h4>Hot Stone</h4>
			<li>60 minute Hot stone massage - P260</li>
			<li>90 minute Hot stone massage - P290</li>

			<h4>Face Toning Massage</h4>
			<li>30 minute Face Toning massage - P230</li>

			<h3>FACIALS</h3>
			<li>30 minute massage - P230</li>
			<li>60 minute massage - P260</li>
			<li>90 minute massage - P290</li>

			<h4>DermaRadiance</h4>
			<li>45 minutes - P245</li>
			<li>60 minutes - P260</li>

			<h4>Brilliant Back Treatment</h4>
			<li>45 minutes - P245</li>

			<h4>Customized Facial&nbsp;</h4>
			<li>60 minutes - P260</li>
			
			<h4>Firm and Lift Facial</h4>
			<li>60 minutes - P260</li>

			<h4>Ultimate Detox Facial&nbsp;</h4>
			<li>60 minutes - P260</li>

			<h4>Calming Facial</h4>
			<li>60 minute - P260</li>

			<h4>Acne Clearing Facial</h4>
			<li>60 minute - P260</li>

			<h4>Men’s Facial</h4>
			<li>60 minute – P260</li>

			<h3>BODY TREATMENTS</h3>
			<li>30 minute massage - P230</li>
			<li>60 minute massage - P260</li>
			<li>90 minute massage - P290</li>

			<h3>MANICURES</h3>
			<li>Child's manicure - P120 &amp; up</li>
			<li>Classic manicure - P150 &amp; up</li>
			<li>Gentlemen’s Manicure - P180 &amp; up</li>
			<li>Shellac Manicure - P190 &amp; up</li>
			<li>Spa manicure - P190 &amp; up</li>

			<br>Additional Services:</br>
			<li>French Polish - P100 &amp; up</li>
			<li>Nail Art, per nail - P60 &amp; up</li>
			<li>Nail repair - P80</li>
			<li>Paraffin treatment for hands - P80</li>
			<li>Paraffin treatment for feet - P80</li>
			<li>Soak off- Gel - P90 &amp; up</li>
			<li>Soak off- Shellac - P90 &amp; up</li>
			<li>Vinylux Polish - P90 &amp; up</li>

			<h3>PEDICURES</h3>
			<li>Classic pedicure - P145 &amp; up</li>
			<li>GentleMEN’s Pedicure - P130 &amp; up</li>
			<li>Mini Pedicure - P130 &amp; up</li>
			<li>Spa pedicure - P160 &amp; up</li>

			<br>Additional Services:</br>
			<li>French Polish - P100 &amp; up</li>
			<li>Nail Art, per nail - P60 &amp; up</li>
			<li>Nail repair - P80</li>
			<li>Paraffin treatment for hands - P80</li>
			<li>Paraffin treatment for feet - P80</li>
			<li>Soak off- Gel - P90 &amp; up</li>
			<li>Soak off- Shellac - P90 &amp; up</li>
			<li>Vinylux Polish - P90 &amp; up</li>

			<h3>WAXING</h3>
			<h4>Female Facial Waxing - P100</h4>
			<li>Eyebrow Shaping - P130 &amp; up</li>
			<li>Lip - P120</li>
			<li>Cheeks - P120 &amp; up</li>
			<li>Chin - P120</li>
			<li>Whole Face - P140 &amp; up</li>

			<h4>Female Body Waxing</h4>
			<li>American Basic Bikini - P135</li>
			<li>Brazilian - P170</li>
			<li>French Brazilian - P160</li>
			<li>Legs – full - P195</li>
			<li>Legs – upper - P150</li>
			<li>Legs – lower - knee down - P140</li>
			<li>Stomach - P120/P140</li>
			<li>Arms- Full - P150</li>
			<li>Arms- Elbow Down - P130</li>
			<li>Underarms - P125</li>
			<li>Feet / toe - P110</li>
			<li>Hand / finger - P110</li>
			<li>Bottom - P160</li>
			<li>Neck - P130</li>

			<h4>Male Facial Waxing</h4>
			<li>Brow – P115</li>
			<li>Ear Lobes &amp; Ear Lobes &amp; Canal – P120</li>
			<li>Hair Line – P130</li>

			<h4>Male Body Waxing</h4>
			<li>Arms full - P160</li>
			<li>Shoulders - P120</li>
			<li>Back full - P190</li>
			<li>Back &amp; Shoulder- P190</li>
			<li>Chest – P160</li>
			<li>Stomach – P160</li>

			<h3>EYELASH EXTENSIONS</h3>
			<li>Full Set – P275</li>
			<li>Eye Lash Tinting- P30 (Black and Brown Available)</li>
			
			<h3>MAKEUP APPLICATION</h3>
			<li>make-up application (1/2 hour) - P240 &amp; up</li>
			<li>make-up lesson - P350 &amp; up</li>
			<li>party lashes applied during application - P180</li>
			<br><hr>
		</div>
				
		<div>
			<nav class="navbar-fixed-bottom text-center">
				&copyEdrein Salon and Spa
			</nav>
		</div>

		<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script> 
		<script src="jquery/jquery-3.1.1.min.js"></script>
		<script src="jquery/jquery-3.1.1.slim.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>


		</body>

	</html>